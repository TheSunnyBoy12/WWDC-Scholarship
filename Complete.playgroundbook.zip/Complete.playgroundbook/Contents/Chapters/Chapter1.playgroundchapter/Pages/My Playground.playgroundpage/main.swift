import SwiftUI
import PlaygroundSupport
import SwiftUI

struct MercuryView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.5704585314, green: 0.5704723597, blue: 0.5704649091, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Mercury")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                        Text("\u{2022} Mass: 3.285 × 10")
                            .font(.system(size: 25))
                            .foregroundColor(txtColor)
                            + Text("23") 
                            .foregroundColor(txtColor)
                            .font(.system(size: 12.0))
                            .baselineOffset(10.0)
                            + Text(" kg")
                            .foregroundColor(txtColor)
                            .font(.system(size: 25))
                        Text("\u{2022} How long a day lasts here: 58 and a half Earth day")
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(txtColor)
                            .font(.system(size:25))
                            .frame(alignment: .trailing)
                        Text("\u{2022} How long is a year here: 88 days")
                            .font(.system(size:25))
                            .foregroundColor(txtColor)
                        Text("\u{2022} Mercury is the fastest planet we have in the solar system, earning it a nickname (can you guess what it is?). It travels around the Sun at a speed of 180,000 km/h!")
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(txtColor)
                            .font(.system(size:25))
                            .frame(alignment: .trailing)
                        Text("\u{2022} While being the fastest planet around, it is also the smallest and closest to the Sun.")
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(txtColor)
                            .font(.system(size:25))
                            .frame(alignment: .trailing)
                    }
                    }
                }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.413330614566803, green: 0.4234243631362915, blue: 0.4069623649120331, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Swift Planet")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        Text("Mercury is the Solar System's smallest and nearest planet to the Sun. Its orbit around the Sun is the shortest in the Solar System, taking 87.97 Earth days. Mercury got its name from Mercurius, the Roman god of trade, messenger of the gods, and mediator between gods and mortals, was given the name. \n \nMercury is one of four terrestrial planets in the Solar System, and is a rocky body like Earth. Its density is the second highest in the Solar System, only slightly less than Earth's density \n")
                            
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(txtColor)
                            .font(.system(size:25))
                            .frame(alignment: .trailing)
                    }
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .padding()
                    .background(Color(.darkGray))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    
                    }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                ScrollView (.horizontal) {
                    HStack {
                        VStack{
                            HStack{
                            Image(uiImage: #imageLiteral(resourceName: "merc1.jpeg"))
                                .frame(height: 200)
                            Image(uiImage: #imageLiteral(resourceName: "merc2.jpeg"))
                                .frame(height: 200)
                            Image(uiImage: #imageLiteral(resourceName: "merc3.jpeg"))
                                .frame(height: 200)
                        }
                            Text("Some images we have taken of Mercury")
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                    }
                        Divider()
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "merc4.jpeg"))
                            }
                            Text("Mariner 10 - the first satellite we sent to Mercury.")
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                    }
                    .padding([.leading, .trailing], 50)
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                Button(action: {
                    PlaygroundPage.current.setLiveView(ContentView())
                }) {
                    HStack{
                        Text("Go Back")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                            .shadow(radius: 10)
                            .cornerRadius(40)
                            .foregroundColor(.white)
                            .padding(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 40)
                                    .stroke(Color(#colorLiteral(red: 0.3747495114803314, green: 0.3747495114803314, blue: 0.3747495114803314, alpha: 1.0)), lineWidth: 5)
                            )
                    }
                    .padding(.bottom, 50)
                    // How the button looks like
                }
            }
        }
    }
}
struct VenusView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.8598117828369141, green: 0.7103297114372253, blue: 0.5116791725158691, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Venus")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 4.867 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("24") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} How long a day lasts here: 117 days")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} How long is a year here: 225 days")
                                    .font(.system(size:25))
                                    .foregroundColor(txtColor)
                                Text("\u{2022} Venus is the hottest planet we have in the Solar System, althoughg it's not the closest to the Sun!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Venus spins clockwise, unlike other planets in the Solar System.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.8274509803921568, green: 0.6470588235294118, blue: 0.403921568627451, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Morning Star")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        Text("Venus is the second planet from te Sun. It is named after the Roman goddess of love and beauty. As the brightest natural object in Earth's night sky after the Moon, Venus is sometmes even visible to the naked eye in broad daylight (try looking for it some day, after sunset or before sunrise).\nVenus orbits the Sun every 224 days. With a rotation period of 243 days, it takes longer to rotate about its axis than any other planet in the Solar System and does so in the opposite direction to most planets (Uranus does the same).\nWith thick clouds and a very heavy atmosphere, not a lot of heat escapes Venus meaning that any heat from the Sun just heats up the planet and never escapes into space (greenhouse effect). On top of that, Venus has a lot of volcanoes which are very active making it even hotter. So hot in fact, you won't even be able to get there before turning into vapor!")
                            
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(txtColor)
                            .font(.system(size:25))
                            .frame(alignment: .trailing)
                    }
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .padding()
                    .background(Color(#colorLiteral(red: 0.6784313725490196, green: 0.5529411764705883, blue: 0.32941176470588235, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                ScrollView (.horizontal) {
                    HStack {
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "venu1.jpg"))
                                    .frame(height: 200)
                                Divider()
                                Image(uiImage: #imageLiteral(resourceName: "Venu2.jpg"))
                                    .frame(height: 200)
                                Divider()
                                Image(uiImage: #imageLiteral(resourceName: "Venu3.jpg"))
                                    .frame(height: 200)
                            }
                            Text("Some images we have taken of Venus.\nIt even looks hot doesn't it?")
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                        Divider()
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "venu4.jpg"))
                                Image(uiImage: #imageLiteral(resourceName: "venu5.jpg"))
                            }
                            Text("Venus is known for being very hot and having lots of volcanoes.\nNotice the bright color of the surface.")
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                        Divider()
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "venu6.jpg"))
                            }
                            Text("Mariner 2 - the first satellite we sent to get\npictures of Venus.")
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                    }
                    .padding([.leading, .trailing], 50)
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                Button(action: {
                    PlaygroundPage.current.setLiveView(ContentView())
                }) {
                    HStack{
                        Text("Go Back")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                            .shadow(radius: 10)
                            .cornerRadius(40)
                            .foregroundColor(.white)
                            .padding(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 40)
                                    .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                            )
                    }
                    .padding(.bottom, 50)
                    // How the button looks like
                }
            }
        }
    }
}
struct EarthView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.06274509803921569, green: 0.7568627450980392, blue: 0.20784313725490194, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Earth")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 5.972 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("24") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} It's the only known planet with life!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Earth is the 5th largest planet in the Solar System. It is the biggest rocky planet in the Solar System as well.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} The highest point on Earth is Mt. Everest at a height of 8.8 km")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.308306247, green: 0.4779683352, blue: 0.1554028392, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Blue Marble")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                        Text("The Earth is the third planet from the Sun and the only known astronomical object to have life on it. Land, consisting of continents and islands, co ers about 29% of the Earth's surface while water covers the remaining 71%, mainly in the form of oceans, seas, gulfs, and other  salt water bodies, but also in the fom of lakes, rivers, and other ffresh water bodies, which together make up the hydrosphere. \nThe Earth's shape isn't exactly a sphere as you might think - it's called an oblate spheroid, basically meaning it's a sphere with flatter tops. We get this shpe because of how fast the Earth is spinning (which gives us day and night). \nEarth gets its nickname 'Blue Marble' from what it looked like when we first saw it from space - a blue ball, like a marble, floating in space.")
                            
                            .fixedSize(horizontal: false, vertical: true)
                            .foregroundColor(txtColor)
                            .font(.system(size:25))
                            .frame(alignment: .trailing)
                    }
                    }
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .padding()
                    .background(Color(#colorLiteral(red: 0.1481023431, green: 0.2412780225, blue: 0.0572719276, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack{
                ScrollView (.horizontal) {
                    HStack {
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "eart1.jpg"))
                                    .frame(height: 200)
                                Image(uiImage: #imageLiteral(resourceName: "eart4.jpg"))
                                    .frame(height: 200)
                            }
                            Text("Our own home planet. Can you see why it's called the Blue Marble?")
                                .padding(.top, 15)
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                        Divider()
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "eart2.jpg"))
                                Image(uiImage: #imageLiteral(resourceName: "eart5.jpg"))
                            }
                            Text("Mount Everest - the highest point on the Earth and the Mariana Trench - the lowest point on the Earth.")
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                        Divider()
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "eart6.jpg"))
                            }
                            Text("Being the only planet with life makes the Earth very precious and special. How many animals can you name from above?")
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                    }
                    .padding([.leading, .trailing], 50)
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                    Spacer()
                Button(action: {
                    PlaygroundPage.current.setLiveView(ContentView())
                }) {
                    HStack{
                        Text("Go Back")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                            .shadow(radius: 10)
                            .cornerRadius(40)
                            .foregroundColor(.white)
                            .padding(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 40)
                                    .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                            )
                    }
                    .padding(.bottom, 5)
                    // How the button looks like
                }
            }
        }
    }
}
}
struct MarsView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.8, green: 0.11764705882352941, blue: 0.17254901960784313, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Mars")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 6.39 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("23") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} How long does a day last here: Almost exactly one Earth day!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Length of a year here: 687 days")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} The largest volcano in all of the Solar System is on Mars - called the Olympus Mons")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Mars has two moons - Phobos and Deimos")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} In about 20 million years, Mars will have rings when its moon gets shredded to pieces by gravity.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.7105483413, green: 0.1038654521, blue: 0.0, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Red Planet!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("Mars is a cold desert world. It is half the size of Earth. Mars is sometimes called the Red Planet. It's red because of rusty iron in the ground.\nLike Earth, Mars has seasons, polar ice caps, volcanoes, canyons, and weather. It has a very thin atmosphere made of carbon dioxide, nitrogen, and argon.\nThere are signs of ancient floods on Mars, but now water mostly exists in icy dirt and thin clouds. On some Martian hillsides, there is evidence of liquid salty water in the ground.\nScientists want to know if Mars may have had living things in the past. They also want to know if Mars could support life now or in the future.\n(Source: NASA)")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.5123859048, green: 0.0651082322, blue: 0.0, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack(spacing: 6){
                    ScrollView (.horizontal) {
                    HStack {
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "mars1.jpg"))
                                    .frame(height: 200)
                                Image(uiImage: #imageLiteral(resourceName: "mars2.jpg"))
                                    .frame(height: 200)
                            }
                            Text("Notice the bright and distinct red color!")
                                .padding(.top, 15)
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                        Divider()
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "mars3.jpg"))
                                Image(uiImage: #imageLiteral(resourceName: "mars4.jpg"))
                            }
                            Text("Olympus Mons - the highest mountain in the Solar System. It's also an inactive volcano.")
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                        Divider()
                        
                        VStack{
                            HStack{
                                Image(uiImage: #imageLiteral(resourceName: "mars5.jpg"))
                                Image(uiImage: #imageLiteral(resourceName: "mars7.jpg"))
                            }
                            Text("To explore and learn more about Mars, we have sent many rovers which study the rock there. We have even sent a drone there!")
                                .fixedSize(horizontal: false, vertical: true)
                                .multilineTextAlignment(.center)
                                .font(.system(size: 20))
                        }
                    }
                    .padding([.leading, .trailing], 50)
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                
                Button(action: {
                    PlaygroundPage.current.setLiveView(ContentView())
                }) {
                    HStack{
                        Text("Go Back")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                            .shadow(radius: 10)
                            .cornerRadius(40)
                            .foregroundColor(.white)
                            .padding(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 40)
                                    .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                            )
                    }
                    .padding(.bottom, 50)
                    // How the button looks like
                }
                }
            }
        }
    }
}
struct JupiterView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.8774569630622864, green: 0.8273891806602478, blue: 0.6776183247566223, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Jupiter")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 1.898 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("27") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} How long does a day last here: Only 10 hours!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Length of a year here: 12 years")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} It is the largest planet in the Solar System")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Jupiter has had a storm the size of the Earth - for 350 years now!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Jupiter has the largest moon in the Solar System - Ganymede")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.7077465057373047, green: 0.6360668540000916, blue: 0.5958697199821472, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Gas Giant!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("Jupiter is the largest planet in the Solar System and is the fifth planet from the sun. It is more than 300 times more massive than Earth and is more than two times as massive than all the other planets combined. Jupiter is called a gas giant planet.\nThrough the observations of Jupiter, the discovery of the four Galilean moons ended the belief that everything revolved around the Earth. It has a total of 79 confirmed moons. It is second only to Saturn when it comes to the total amount of satellites.\nJupiter has been known since ancient times because it can be seen without advanced telescopes. It has also been visited or passed by several spacecraft, orbiters and probes, such as Pioneer 10 and 11, Voyager 1 and 2, Cassini, New Horizons, and Juno. (Source: NASA)")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.5123859048, green: 0.0651082322, blue: 0.0, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack(spacing: 6){
                    ScrollView (.horizontal) {
                        HStack {
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "jup2.jpg"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "jup3.jpg"))
                                        .frame(height: 200)
                                }
                                Text("Jupiter - the Giant. Notice the moon in the first picture, it's Ganymede!")
                                    .padding(.top, 15)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "jup1.jpg"))
                                }
                                Text("The Great Red Spot. Quite the storm isn't it?")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "jup4.jpg"))
                                    Image(uiImage: #imageLiteral(resourceName: "jup5.jpg"))
                                }
                                Text("Juno - a satellite we sent to study Jupiter and Cassini - a satellite which helped us picture a lot of the planet.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                        }
                        .padding([.leading, .trailing], 50)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                    
                    Button(action: {
                        PlaygroundPage.current.setLiveView(ContentView())
                    }) {
                        HStack{
                            Text("Go Back")
                                .fontWeight(.bold)
                                .font(.title)
                                .padding()
                                .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                                .shadow(radius: 10)
                                .cornerRadius(40)
                                .foregroundColor(.white)
                                .padding(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 40)
                                        .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                                )
                        }
                        .padding(.bottom, 50)
                        // How the button looks like
                    }
                }
            }
        }
    }
}
struct SaturnView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.8162065148353577, green: 0.7228139042854309, blue: 0.5053838491439819, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Saturn")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 5.683 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("26") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} How long does a day last here: Only 10.5 hours!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Length of a year here: 29 years")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Saturn is the farthest planet we can see with just our naked eye.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} It has the most moons out of any planet in the Solar System")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Saturn has the most distinctive ring in our Solar System")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.8102112412452698, green: 0.6899664998054504, blue: 0.5169959664344788, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Ringed Planet!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("Best known for its fabulous ring system, Saturn is the sixth planet from the Sun and the second largest in our solar system. Like Jupiter, Saturn is a gas giant and is composed of similar gasses.\nWhile all the gas giants in our solar system have rings none of them are as extensive or distinctive as Saturn’s. The rings were discovered by Galileo Galilei 1610 who observed them with a telescope. The first ‘up close’ view of the rings were by Pioneer 11 spacecraft which flew by Saturn on September 1, 1971.\nSaturn’s atmosphere is composed primarily of hydrogen and helium with very little of other substances like methane. Winds in the upper atmosphere can reach speeds of 500 metres a second, these combined with heat rising from within the planet’s interior cause yellow and gold bands.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.7032799124717712, green: 0.6677061319351196, blue: 0.5211576223373413, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack(spacing: 6){
                    ScrollView (.horizontal) {
                        HStack {
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "sat1.jpg"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "sat2.jpg"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "sat3.jpg"))
                                        .frame(height: 200)
                                }
                                Text("Saturn - notice the large and distinctive rings that can be seen.")
                                    .padding(.top, 15)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "sat4.gif"))
                                }
                                Text("Galileo - the astronomer who discovered Saturn")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "jup5.jpg"))
                                }
                                Text("Cassini - the satellite which has helped us a lot in learning about Saturn.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                        }
                        .padding([.leading, .trailing], 50)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                    
                    Button(action: {
                        PlaygroundPage.current.setLiveView(ContentView())
                    }) {
                        HStack{
                            Text("Go Back")
                                .fontWeight(.bold)
                                .font(.title)
                                .padding()
                                .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                                .shadow(radius: 10)
                                .cornerRadius(40)
                                .foregroundColor(.white)
                                .padding(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 40)
                                        .stroke(Color(#colorLiteral(red: 0.3746541142463684, green: 0.3748083710670471, blue: 0.3746454417705536, alpha: 1.0)), lineWidth: 5)
                                )
                        }
                        .padding(.bottom, 50)
                        // How the button looks like
                    }
                }
            }
        }
    }
}
struct UranusView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.7775678634643555, green: 0.9036009907722473, blue: 0.9152934551239014, alpha: 1.0))
            var txtColor = Color(.black)
            VStack{
                VStack{
                    Text("Uranus")
                        .bold()
                        .foregroundColor(.black)
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 8.681 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("25") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} How long does a day last here: 17 hours")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Length of a year here: 84 years")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Uranus is known as the “sideways planet” because it rotates on its side.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Uranus was the first planet found using a telescope.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Uranus is an ice giant")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.6393272876739502, green: 0.7694229483604431, blue: 0.7913458943367004, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Ringed Planet!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("The first planet found with the aid of a telescope, Uranus was discovered in 1781 by astronomer William Herschel, although he originally thought it was either a comet or a star.\n \nIt was two years later that the object was universally accepted as a new planet, in part because of observations by astronomer Johann Elert Bode. Herschel tried unsuccessfully to name his discovery Georgium Sidus after King George III. Instead the scientific community accepted Bode's suggestion to name it Uranus, the Greek god of the sky, as suggested by Bode.​\n \nFun Fact: Uranus' unique sideways rotation makes for weird seasons. The planet's north pole experiences 21 years of nighttime in winter, 21 years of daytime in summer and 42 years of day and night in the spring and fall.\n \nUranus also has faint rings. The inner rings are narrow and dark. The outer rings are brightly colored and easier to see.\nLike Venus, Uranus rotates in the opposite direction as most other planets. And unlike any other planet, Uranus rotates on its side.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.46806466579437256, green: 0.5946546196937561, blue: 0.6145257353782654, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack(spacing: 6){
                    ScrollView (.horizontal) {
                        HStack {
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "ura2.jpg"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "ura3.jpg"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "sat3.jpg"))
                                        .frame(height: 200)
                                }
                                Text("Uranus - can you see the faint rings it has?")
                                    .foregroundColor(.black)
                                    .padding(.top, 15)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "ura1.jpg"))
                                }
                                Text("William Herschel - discoverer of Uranus")
                                    .foregroundColor(.black)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                        }
                        .padding([.leading, .trailing], 50)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                    
                    Button(action: {
                        PlaygroundPage.current.setLiveView(ContentView())
                    }) {
                        HStack{
                            Text("Go Back")
                                .fontWeight(.bold)
                                .font(.title)
                                .padding()
                                .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                                .shadow(radius: 10)
                                .cornerRadius(40)
                                .foregroundColor(.white)
                                .padding(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 40)
                                        .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                                )
                        }
                        .padding(.bottom, 50)
                        // How the button looks like
                    }
                }
            }
        }
    }
}
struct NeptuneView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.588648796081543, green: 0.7369083762168884, blue: 0.8868070244789124, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("Neptune")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} Mass: 1.024 × 10")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                    + Text("26") 
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 12.0))
                                    .baselineOffset(10.0)
                                    + Text(" kg")
                                    .foregroundColor(txtColor)
                                    .font(.system(size: 25))
                                Text("\u{2022} How long does a day last here: 16 hours")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Length of a year here: 165 years")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Neptune is the most distant planet from the Sun")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} The strongest winds in the Solar System happen on this planet!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} It is also the coldest planet in the Solar System.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.4329546391963959, green: 0.4648376703262329, blue: 0.9000800251960754, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    VStack(alignment: .leading, spacing: 10){
                        Text("The Watery Planet!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("Dark, cold and whipped by supersonic winds, ice giant Neptune is the eighth and most distant planet in our solar system. More than 30 times as far from the Sun as Earth, Neptune is the only planet in our solar system not visible to the naked eye and the first predicted by mathematics before its discovery. In 2011 Neptune completed its first 165-year orbit since its discovery in 1846.\n \nNASA's Voyager 2 is the only spacecraft to have visited Neptune up close. It flew past in 1989 on its way out of the solar system.\n \nFun Fact: Neptune is our solar system's windiest world. Winds whip clouds of frozen methane across the planet at speeds of more than 2,000 km/h \n\n Neptune is very similar to Uranus. It's made of a thick soup of water, ammonia, and methane over an Earth-sized solid center. Its atmosphere is made of hydrogen, helium, and methane. The methane gives Neptune the same blue color as Uranus. (Source: NASA)")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.198805570602417, green: 0.3551153838634491, blue: 0.6004884243011475, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack(spacing: 6){
                    ScrollView (.horizontal) {
                        HStack {
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "nep1.jpg"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "nep2.jpg"))
                                        .frame(height: 200)
                                }
                                Text("Neptune - the blue even makes it look icey doesn't it?")
                                    .foregroundColor(.black)
                                    .padding(.top, 15)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "nep3.jpg"))
                                }
                                Text("Urbain Le Verrier - commonly believed to be the discoverer of Neptune")
                                    .foregroundColor(.black)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "nep4.jpg"))
                                }
                                Text("The Voyager spacecraft which has not only helped us learn a lot more about Neptune than possible without it, it is also the spacecraft which has travelled the farthest")
                                    .foregroundColor(.black)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                        }
                        .padding([.leading, .trailing], 50)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                    
                    Button(action: {
                        PlaygroundPage.current.setLiveView(ContentView())
                    }) {
                        HStack{
                            Text("Go Back")
                                .fontWeight(.bold)
                                .font(.title)
                                .padding()
                                .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                                .shadow(radius: 10)
                                .cornerRadius(40)
                                .foregroundColor(.white)
                                .padding(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 40)
                                        .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                                )
                        }
                        .padding(.bottom, 50)
                        // How the button looks like
                    }
                }
            }
        }
    }
}
struct SunView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 1.00172758102417, green: 0.908549427986145, blue: 0.5871211886405945, alpha: 1.0))
            var txtColor = Color(.white)
            VStack{
                VStack{
                    Text("The Sun")
                        .bold()
                        .underline()
                        .font(.system(size: 70))
                        .padding(.top, 40)
                }
                .padding(.bottom, 20)
                HStack{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Quick Facts!")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("\u{2022} The Sun is the largest object within our solar system")
                                    .font(.system(size: 25))
                                    .foregroundColor(txtColor)
                                Text("\u{2022} The Sun is located at the center of our solar system, and Earth orbits 93 million miles away from it")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Sun is what we call a yellow dwarf star because of it's size and brightness.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} Without the Sun's intense energy, there would be no life on Earth.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} The Sun is about 4.5 billion years old!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                                Text("\u{2022} The Sun is more than a 100 times larger than the Earth!")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 1.003311038017273, green: 0.8298398852348328, blue: 0.25436824560165405, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    VStack(alignment: .leading, spacing: 10){
                        Text("Sun, Sol and the Solar System")
                            .underline()
                            .font(.system(size: 40))
                            .foregroundColor(txtColor)
                            .padding(.bottom, 10)
                        ScrollView{
                            VStack(alignment: .leading, spacing: 10){
                                Text("The Sun—the heart of our solar system—is a yellow dwarf star, a hot ball of glowing gases.\n \nIts gravity holds the solar system together, keeping everything from the biggest planets to the smallest particles of debris in its orbit. Electric currents in the Sun generate a magnetic field that is carried out through the solar system by the solar wind—a stream of electrically charged gas blowing outward from the Sun in all directions.\n \nThe connection and interactions between the Sun and Earth drive the seasons, ocean currents, weather, climate, radiation belts and aurorae. Though it is special to us, there are billions of stars like our Sun scattered across the Milky Way galaxy.")
                                    .fixedSize(horizontal: false, vertical: true)
                                    .foregroundColor(txtColor)
                                    .font(.system(size:25))
                                    .frame(alignment: .trailing)
                            }
                        }
                    }
                    .padding()
                    .frame(minWidth: 0,
                           maxWidth: .infinity,
                           minHeight: 0,
                           maxHeight: .infinity)
                    .background(Color(#colorLiteral(red: 0.9971035122871399, green: 0.6528679728507996, blue: -0.0262607391923666, alpha: 1.0)))
                    .cornerRadius(15)
                    .shadow(radius: 40)   
                    
                    
                }
                .padding()
                .frame(minWidth: 0,
                       maxWidth: .infinity,
                       minHeight: 0,
                       maxHeight: .infinity)
                VStack(spacing: 6){
                    ScrollView (.horizontal) {
                        HStack {
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "sun1.webp"))
                                        .frame(height: 200)
                                    Image(uiImage: #imageLiteral(resourceName: "sun2.jpg"))
                                        .frame(height: 200)
                                }
                                Text("The Sun normally, and during a solar eclipse")
                                    .foregroundColor(.black)
                                    .padding(.top, 15)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                            VStack{
                                HStack{
                                    Image(uiImage: #imageLiteral(resourceName: "sun3.jpg"))
                                }
                                Text("The Parker Solar Probe is a NASA project which will be entering the Sun's atmosphere and giving us close and accurate data for the first time!")
                                    .foregroundColor(.black)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .multilineTextAlignment(.center)
                                    .font(.system(size: 20))
                            }
                            Divider()
                        }
                        .padding([.leading, .trailing], 50)
                    }
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                    
                    Button(action: {
                        PlaygroundPage.current.setLiveView(ContentView())
                    }) {
                        HStack{
                            Text("Go Back")
                                .fontWeight(.bold)
                                .font(.title)
                                .padding()
                                .background(Color(#colorLiteral(red: 0.1353607475757599, green: 0.1353607475757599, blue: 0.1353607475757599, alpha: 1.0)))
                                .shadow(radius: 10)
                                .cornerRadius(40)
                                .foregroundColor(.white)
                                .padding(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 40)
                                        .stroke(Color(#colorLiteral(red: 0.37470948696136475, green: 0.37477749586105347, blue: 0.3747006058692932, alpha: 1.0)), lineWidth: 5)
                                )
                        }
                        .padding(.bottom, 50)
                        // How the button looks like
                    }
                }
            }
        }
    }
}
struct ContentView: View{
    var body: some View{
        ZStack{
            Color(#colorLiteral(red: 0.5786082745, green: 0.8915666938, blue: 0.994461596, alpha: 1.0))
            
            ScrollView{
                Button(action: {
                    PlaygroundPage.current.setLiveView(SunView())
                }) {
                    HStack{
                        
                        Text("Learn about the Sun!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(MercuryView())
                }) {
                    HStack{
                        
                        Text("Learn about Mercury!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(VenusView())
                }) {
                    HStack{
                        
                        Text("Learn about Venus!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(EarthView())
                }) {
                    HStack{
                        
                        Text("Learn about Earth!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(MarsView())
                }) {
                    HStack{
                        
                        Text("Learn about Mars!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(JupiterView())
                }) {
                    HStack{
                        
                        Text("Learn about Jupiter!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(SaturnView())
                }) {
                    HStack{
                        
                        Text("Learn about Saturn!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(UranusView())
                }) {
                    HStack{
                        
                        Text("Learn about Uranus!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                Button(action: {
                    PlaygroundPage.current.setLiveView(NeptuneView())
                }) {
                    HStack{
                        
                        Text("Learn about Neptune!")
                            .fontWeight(.bold)
                            .font(.title)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.black)
                            .padding(10)
                            .overlay(
                                Rectangle()
                                    .stroke(Color.white, lineWidth: 5)
                            )
                    }
                    // How the button looks like
                }
                
            }
        }.padding([.top,.bottom], 50)
    }
}
//  struct ContentView: View {
//      
//      var body: some View{
//          ZStack{
//              Color(#colorLiteral(red: 0.800970614, green: 0.9103804827, blue: 0.7090534568, alpha: 1.0))
//              VStack{
//                  Button(action: {
//                      PlaygroundPage.current.setLiveView(learnView())
//                  }) {
//                      HStack{
//                          Text("Learn about the Planets and the Sun")
//                              .fontWeight(.bold)
//                              .font(.title)
//                              .padding()
//                              .background(Color(#colorLiteral(red: 1.0855402946472168, green: 0.2385406792163849, blue: 0.2203029990196228, alpha: 1.0)))
//                              .shadow(radius: 30)
//                              .cornerRadius(40)
//                              .foregroundColor(.white)
//                              .padding(10)
//                              .overlay(
//                                  RoundedRectangle(cornerRadius: 40)
//                                      .stroke(Color(#colorLiteral(red: 1.0855402946472168, green: 0.2385406792163849, blue: 0.2203029990196228, alpha: 1.0)), lineWidth: 5)
//                              )
//                      }
//                      .padding(.bottom, 50)
//                  }
//              }
//              
//              
//          }
//      }
//  }
PlaygroundPage.current.wantsFullScreenLiveView = true
PlaygroundPage.current.setLiveView(ContentView())
